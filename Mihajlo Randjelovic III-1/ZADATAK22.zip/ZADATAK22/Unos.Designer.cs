﻿namespace ZADATAK22
{
    partial class Unos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtsif = new System.Windows.Forms.TextBox();
            this.txtproiz = new System.Windows.Forms.TextBox();
            this.txtmodel = new System.Windows.Forms.TextBox();
            this.txtgodina = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtboja = new System.Windows.Forms.TextBox();
            this.txtcena = new System.Windows.Forms.TextBox();
            this.btupisi = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(286, 110);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(28, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Sifra";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(286, 162);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Model";
            // 
            // txtsif
            // 
            this.txtsif.Location = new System.Drawing.Point(353, 107);
            this.txtsif.Name = "txtsif";
            this.txtsif.Size = new System.Drawing.Size(100, 20);
            this.txtsif.TabIndex = 2;
            // 
            // txtproiz
            // 
            this.txtproiz.Location = new System.Drawing.Point(353, 133);
            this.txtproiz.Name = "txtproiz";
            this.txtproiz.Size = new System.Drawing.Size(100, 20);
            this.txtproiz.TabIndex = 3;
            // 
            // txtmodel
            // 
            this.txtmodel.Location = new System.Drawing.Point(353, 159);
            this.txtmodel.Name = "txtmodel";
            this.txtmodel.Size = new System.Drawing.Size(100, 20);
            this.txtmodel.TabIndex = 4;
            // 
            // txtgodina
            // 
            this.txtgodina.Location = new System.Drawing.Point(353, 184);
            this.txtgodina.Name = "txtgodina";
            this.txtgodina.Size = new System.Drawing.Size(100, 20);
            this.txtgodina.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(286, 136);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Proizvođač";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(286, 187);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(43, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Godište";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(286, 239);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(32, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Cena";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(286, 213);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(28, 13);
            this.label6.TabIndex = 9;
            this.label6.Text = "Boja";
            // 
            // txtboja
            // 
            this.txtboja.Location = new System.Drawing.Point(353, 210);
            this.txtboja.Name = "txtboja";
            this.txtboja.Size = new System.Drawing.Size(100, 20);
            this.txtboja.TabIndex = 10;
            // 
            // txtcena
            // 
            this.txtcena.Location = new System.Drawing.Point(353, 236);
            this.txtcena.Name = "txtcena";
            this.txtcena.Size = new System.Drawing.Size(100, 20);
            this.txtcena.TabIndex = 11;
            // 
            // btupisi
            // 
            this.btupisi.Location = new System.Drawing.Point(289, 262);
            this.btupisi.Name = "btupisi";
            this.btupisi.Size = new System.Drawing.Size(164, 42);
            this.btupisi.TabIndex = 12;
            this.btupisi.Text = "Dodaj";
            this.btupisi.UseVisualStyleBackColor = true;
            this.btupisi.Click += new System.EventHandler(this.btupisi_Click);
            // 
            // Unos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btupisi);
            this.Controls.Add(this.txtcena);
            this.Controls.Add(this.txtboja);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtgodina);
            this.Controls.Add(this.txtmodel);
            this.Controls.Add(this.txtproiz);
            this.Controls.Add(this.txtsif);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Unos";
            this.Text = "Unos";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtsif;
        private System.Windows.Forms.TextBox txtproiz;
        private System.Windows.Forms.TextBox txtmodel;
        private System.Windows.Forms.TextBox txtgodina;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtboja;
        private System.Windows.Forms.TextBox txtcena;
        private System.Windows.Forms.Button btupisi;
    }
}