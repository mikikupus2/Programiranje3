﻿namespace ZADATAK22
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgspisak = new System.Windows.Forms.DataGridView();
            this.btunos = new System.Windows.Forms.Button();
            this.btpregled = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtproiz = new System.Windows.Forms.TextBox();
            this.txtcena = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgspisak)).BeginInit();
            this.SuspendLayout();
            // 
            // dgspisak
            // 
            this.dgspisak.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgspisak.Location = new System.Drawing.Point(75, 38);
            this.dgspisak.Name = "dgspisak";
            this.dgspisak.Size = new System.Drawing.Size(644, 250);
            this.dgspisak.TabIndex = 0;
            // 
            // btunos
            // 
            this.btunos.Location = new System.Drawing.Point(211, 337);
            this.btunos.Name = "btunos";
            this.btunos.Size = new System.Drawing.Size(93, 59);
            this.btunos.TabIndex = 1;
            this.btunos.Text = "Upis";
            this.btunos.UseVisualStyleBackColor = true;
            this.btunos.Click += new System.EventHandler(this.btunos_Click);
            // 
            // btpregled
            // 
            this.btpregled.Location = new System.Drawing.Point(484, 337);
            this.btpregled.Name = "btpregled";
            this.btpregled.Size = new System.Drawing.Size(93, 59);
            this.btpregled.TabIndex = 2;
            this.btpregled.Text = "Pregled";
            this.btpregled.UseVisualStyleBackColor = true;
            this.btpregled.Click += new System.EventHandler(this.btpregled_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(310, 340);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Proizvodjač";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(310, 379);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(32, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Cena";
            // 
            // txtproiz
            // 
            this.txtproiz.Location = new System.Drawing.Point(378, 337);
            this.txtproiz.Name = "txtproiz";
            this.txtproiz.Size = new System.Drawing.Size(100, 20);
            this.txtproiz.TabIndex = 5;
            // 
            // txtcena
            // 
            this.txtcena.Location = new System.Drawing.Point(378, 376);
            this.txtcena.Name = "txtcena";
            this.txtcena.Size = new System.Drawing.Size(100, 20);
            this.txtcena.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtcena);
            this.Controls.Add(this.txtproiz);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btpregled);
            this.Controls.Add(this.btunos);
            this.Controls.Add(this.dgspisak);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dgspisak)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgspisak;
        private System.Windows.Forms.Button btunos;
        private System.Windows.Forms.Button btpregled;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.TextBox txtproiz;
        public System.Windows.Forms.TextBox txtcena;
    }
}

