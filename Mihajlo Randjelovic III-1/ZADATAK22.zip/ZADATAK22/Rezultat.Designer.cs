﻿namespace ZADATAK22
{
    partial class Rezultat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgrez = new System.Windows.Forms.DataGridView();
            this.btok = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgrez)).BeginInit();
            this.SuspendLayout();
            // 
            // dgrez
            // 
            this.dgrez.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgrez.Location = new System.Drawing.Point(60, 34);
            this.dgrez.Name = "dgrez";
            this.dgrez.Size = new System.Drawing.Size(679, 322);
            this.dgrez.TabIndex = 0;
            // 
            // btok
            // 
            this.btok.Location = new System.Drawing.Point(60, 362);
            this.btok.Name = "btok";
            this.btok.Size = new System.Drawing.Size(679, 65);
            this.btok.TabIndex = 1;
            this.btok.Text = "OK";
            this.btok.UseVisualStyleBackColor = true;
            this.btok.Click += new System.EventHandler(this.btok_Click);
            // 
            // Rezultat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btok);
            this.Controls.Add(this.dgrez);
            this.Name = "Rezultat";
            this.Text = "Rezultat";
            this.Load += new System.EventHandler(this.Rezultat_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgrez)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgrez;
        private System.Windows.Forms.Button btok;
    }
}