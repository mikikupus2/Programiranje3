﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ZADATAK22
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public Auto jedno; //Vozila jedno;
        public int brvozila = 0;
        public Auto[] spisak = new Auto[100];

        private void btunos_Click(object sender, EventArgs e)
        {
            Unos frm = new Unos(this);
            jedno = new Auto();
            frm.ShowDialog();

            spisak[brvozila] = jedno;
            brvozila++;
            dgspisak.DataSource = null;
            dgspisak.DataSource = spisak;
            dgspisak.Refresh();
        }

        private void btpregled_Click(object sender, EventArgs e)
        {
            Rezultat frm = new Rezultat(this);
            frm.Show();
        }
    }
}
