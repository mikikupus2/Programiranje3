﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ZADATAK22
{
    public partial class Rezultat : Form
    {
        Form1 Frm;
        public Rezultat(Form1 frm)
        {
            InitializeComponent();
            Frm = frm;
        }
        //Auto[] rezv = new Auto[100];
        List<Auto> rezv = new List<Auto>();
        private void btok_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Rezultat_Load(object sender, EventArgs e)
        {
            int i, n = Frm.brvozila;
            //int j = 0;
            for (i = 0; i < n; i++) 
            {
                if (Frm.spisak[i].Cena >= int.Parse(Frm.txtcena.Text) && int.Parse(Frm.txtproiz.Text) == Frm.spisak[i].Proizvodjac)
                    //rezv[j++] = Frm.spisak[i];
                    rezv.Add(Frm.spisak[i]);
            }
            dgrez.DataSource = null;
            dgrez.DataSource = rezv;
            dgrez.Refresh();
        }
    }
}
