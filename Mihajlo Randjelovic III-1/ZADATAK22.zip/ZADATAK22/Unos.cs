﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ZADATAK22
{
    public partial class Unos : Form
    {
        Form1 Frm;
        public Unos(Form1 frm)
        {
            InitializeComponent();
            Frm = frm;
        }

        private void btupisi_Click(object sender, EventArgs e)
        {
            Frm.jedno = new Auto();
            Frm.jedno.Sifra = int.Parse(txtsif.Text);
            Frm.jedno.Proizvodjac = int.Parse(txtproiz.Text);
            Frm.jedno.Model = txtmodel.Text;
            Frm.jedno.Godiste = int.Parse(txtgodina.Text);
            Frm.jedno.Boja = txtboja.Text;
            Frm.jedno.Cena = int.Parse(txtcena.Text);
            this.Close();
        }
    }
}
