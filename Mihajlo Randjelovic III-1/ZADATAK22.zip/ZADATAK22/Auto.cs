﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZADATAK22 //Automobili
{
    public class Auto //Vozila
    {
        private int sifra, proizvodjac, godiste, cena;
        private string model, boja;

        public int Sifra
        {
            get { return sifra; }
            set { sifra = value; }
        }
        public int Proizvodjac
        {
            get { return proizvodjac; }
            set { proizvodjac = value; }
        }
        public int Godiste
        {
            get { return godiste; }
            set { godiste = value; }
        }
        public int Cena
        {
            get { return cena; }
            set { cena = value; }
        }
        public string Model
        {
            get { return model; }
            set { model = value; }
        }
        public string Boja
        {
            get { return boja; }
            set { boja = value; }
        }
        public Auto(int sifra, int cena)
        {
            this.sifra = sifra;
            this.cena = cena;

        }
        public Auto()
        {
        }
    }
}
